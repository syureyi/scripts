//Modified by Sarnoff for error resilience, 3/5/99
if(!mzte_codec.m_usErrResiDisable)
//End modified by Sarnoff for error resilience, 3/5/99

//Modified by Sarnoff for error resilience, 3/5/99
if(mzte_codec.m_usErrResiDisable)
//End modified by Sarnoff for error resilience, 3/5/99


//Added by Sarnoff for error resilience, 3/5/99
if(!mzte_codec.m_usErrResiDisable)
//End: Added by Sarnoff for error resilience, 3/5/99

//Added by Sarnoff for error resilience, 3/5/99
//End: Added by Sarnoff for error resilience, 3/5/99


//Deleted by Sarnoff for error resilience, 3/5/99
if(!mzte_codec.m_usErrResiDisable)
//End Deleted by Sarnoff for error resilience, 3/5/99

mzte_codec.m_usErrResiDisable